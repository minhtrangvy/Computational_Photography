function A = stack( filter, image )
%stack takes in a filter and an image
% and applies that filter to the image
    
end

